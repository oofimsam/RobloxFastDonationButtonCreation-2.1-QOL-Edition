# Roblox Fast Donation Button Creation [Beta]
A free Roblox plugin to allow easy creation of donation buttons in your game. Also works for shirts, pants and models.

Created by GamersInternational and the Rii-built Studios team.

Fork created by oSudden (samtheman#0637)

Please submit pull requests if you want to help make the plugin better, pull requests that use Rojo will be denied as I want to make sure that anyone with a little coding knowledge can access the code. Donate Robux to help support me push out more updates: https://www.roblox.com/games/6010987912

## Guides

### GitHub Installation

Go to the Releases section and find the latest release then download one of the source code files. Extract the files and move any .rbxmx or .rbxm files to %LocalAppData%\Roblox\Plugins (if this folder doesn't exist, enter Studio > open any game/template > Plugins > Plugin Folder and then it should be created). If your on Mac, instead enter Studio > open a template or whatever game you want > Plugins > Plugin Folder and then drag the .rbxmx or .rbxm files to that folder.

### Editing the source code

Please visit the guide before this to get your plugin directory before you start as you'll need this. Open Roblox Studio and select a template/game you want to edit the source code on. Then make sure Explorer is open and right click Workspace and then Insert From File. Go to your plugin directory and select Roblox Fast Donation Button Creation.rbxmx [if you can't see this, make sure you've downloaded the plugin and make sure your looking for Roblox models [rbxm, rbxmx] not Roblox scripts [lua, txt].

Thank you for using Roblox Fast Donation Button Creation.

Learn more: https://devforum.roblox.com/t/v2-0a1-alpha-v1-3-3-stable-roblox-fast-donation-button-creation-plugin/971984